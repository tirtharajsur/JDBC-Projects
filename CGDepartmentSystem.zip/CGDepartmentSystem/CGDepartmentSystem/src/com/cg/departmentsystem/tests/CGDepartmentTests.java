package com.cg.departmentsystem.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.departmentsystem.beans.Department;
import com.cg.departmentsystem.beans.Students;
import com.cg.departmentsystem.enums.Gender;
import com.cg.departmentsystem.exceptions.InvalidAgeException;
import com.cg.departmentsystem.exceptions.StudentNotFoundException;
import com.cg.departmentsystem.services.DepartmentSystemServices;
import com.cg.departmentsystem.services.DepartmentSystemServicesImpl;
import com.cg.departmentsystem.util.DepartmentSystemDBUtil;

public class CGDepartmentTests {

	private static DepartmentSystemServices services;
	private static Students student;
	
	@BeforeClass
	public static void setUpTestEnv() {
		services = new DepartmentSystemServicesImpl();
		student = new Students();
	}
	
	@Before
	public void setUpTestData() {
		Students student1 = new Students("Tirtharaj", "Sur", 20, Gender.Male,"Kolkata",new Department(11,"CSE","Swagata Paul",1));
		Students student2 = new Students("Rochana", "Sinharay",20, Gender.Female,"Bengaluru", new Department(12,"ECE","Debraj Chatterjee",2));
		Students student3 = new Students("Sayan","Datta",12,Gender.Other,"Puri",new Department(13,"CE","bhola",3));
		
		DepartmentSystemDBUtil.studentDetails.put(student1.getStudentId(), student1);
		DepartmentSystemDBUtil.studentDetails.put(student2.getStudentId(), student2);
		DepartmentSystemDBUtil.studentDetails.put(student3.getStudentId(), student3);
		
		DepartmentSystemDBUtil.ACCOUNT_ID_COUNTER = 103;
	}
	
	@Test
	public void testAcceptStudentDetailsForValidData() throws InvalidAgeException  {
		Assert.assertEquals(10003, services.acceptStudentDetails("Tirtharaj","Sur",22,Gender.Male,"Kolkata",
				11,"CSE","Swagata Paul",1));
	}
	
	
	
	@Test(expected=StudentNotFoundException.class)
	public void testGetStudentDetailsForInvalidAccount() throws StudentNotFoundException {
			services.getStudentDetails(1025);
		
	}
	
	@Test
	public void testGetStudentDetailsForValidAccount() throws StudentNotFoundException {
		Students expectedStudent = new Students(103, "Sayan","Dutta",20,Gender.Male,"Kolkata");
		Students actualStudent = services.getStudentDetails(103);
		Assert.assertEquals(expectedStudent, actualStudent);
	}

	
	
	@Test
	public void testGetAllStudentsDetails() throws StudentNotFoundException {
		Students student1 = new Students("Tirtharaj", "Sur", 20, Gender.Male,"Kolkata",new Department(11,"CSE","Swagata Paul",1));
		Students student2 = new Students("Rochana", "Sinharay",20, Gender.Female,"Bengaluru", new Department(12,"ECE","Debraj Chatterjee",2));
		ArrayList<Students> expectedStudentsList = new ArrayList<>();
		expectedStudentsList.add(student1);
		expectedStudentsList.add(student2);
		ArrayList<Students>actualStudentsList = (ArrayList<Students>)services.getAllStudentsDetails();
		Assert.assertEquals(expectedStudentsList, actualStudentsList);
		
	}

	
	@After
	public void tearDownTestData() {
		DepartmentSystemDBUtil.studentDetails.clear();
		DepartmentSystemDBUtil.ACCOUNT_ID_COUNTER=100;
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		services = null;
		student = null;
	}
	
	

}
