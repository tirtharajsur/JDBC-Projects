package com.cg.departmentsystem.util;
import java.util.HashMap;

import com.cg.departmentsystem.beans.Students;
public class DepartmentSystemDBUtil {
	public static HashMap<Long, Students> studentDetails = new HashMap<>();
	public static int ACCOUNT_ID_COUNTER = 100;
	public static int getACCOUNT_ID_COUNTER() {
		return ++ACCOUNT_ID_COUNTER;
	}

}
