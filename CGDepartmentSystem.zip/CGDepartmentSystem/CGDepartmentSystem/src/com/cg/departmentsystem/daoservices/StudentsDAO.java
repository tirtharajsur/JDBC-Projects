package com.cg.departmentsystem.daoservices;

import java.util.List;

import com.cg.departmentsystem.beans.Students;

public interface StudentsDAO {
	Students save(Students student);
	Students findOne(long studentId );
	List<Students> findAll();
}
