package com.cg.departmentsystem.daoservices;

import java.util.ArrayList;
import java.util.List;
import com.cg.departmentsystem.beans.Students;
import com.cg.departmentsystem.util.DepartmentSystemDBUtil;

public class StudentsDAOImpl implements StudentsDAO{

	@Override
	public Students save(Students student) {
		student.setStudentId(DepartmentSystemDBUtil.getACCOUNT_ID_COUNTER());
		DepartmentSystemDBUtil.studentDetails.put(student.getStudentId(), student);
		return student;
	}

	@Override
	public Students findOne(long studentId) {
		return DepartmentSystemDBUtil.studentDetails.get(studentId);
	
	}

	@Override
	public List<Students> findAll() {
	
		return new ArrayList<Students>(DepartmentSystemDBUtil.studentDetails.values());
	}


}
