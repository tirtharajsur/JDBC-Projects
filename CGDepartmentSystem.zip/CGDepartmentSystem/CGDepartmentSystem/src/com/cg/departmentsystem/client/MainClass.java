package com.cg.departmentsystem.client;

import java.util.Scanner;

import com.cg.departmentsystem.beans.Department;
import com.cg.departmentsystem.beans.Students;
import com.cg.departmentsystem.enums.Gender;
import com.cg.departmentsystem.exceptions.InvalidAgeException;
import com.cg.departmentsystem.exceptions.StudentNotFoundException;
import com.cg.departmentsystem.services.DepartmentSystemServicesImpl;
import com.cg.departmentsystem.services.DepartmentSystemServices;

public class MainClass {

	public static void main(String[] args) throws InvalidAgeException, StudentNotFoundException {

		Scanner sc = new Scanner(System.in);
		DepartmentSystemServices services = new DepartmentSystemServicesImpl();
		Students stud = new Students();
		//long[] student = new long[10];
		int i=0;


		//DepartmentSystemServices services = new DepartmentSystemImpl();

		/*while(true) {
			System.out.println("\t\t...................................OPERATIONS....................................");
			System.out.println("1.Enter Student Details\n2.View Details of a student\n3.View Details of all students\n4.Exit");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				i++;
				System.out.println("Enter First Name:");
				String firstName = sc.next();
				System.out.println("Enter Last Name:");
				String lastName = sc.next();
				System.out.println("Enter your Age: ");
				int age = sc.nextInt();
				System.out.println("Enter gender: 1.Male   2.Female   3.Other");
				int ch = sc.nextInt();
				Gender gender;
				switch(ch) {
				case 1:
					gender = Gender.Male;break;
				case 2:
					gender = Gender.Female;break;
				case 3:
					gender = Gender.Other;break;
				default:
					gender = null;break;
				}
				System.out.println("Enter City:");
				String city = sc.next();
				System.out.println("Enter DepartmentId:");
				int departmentId = sc.nextInt();
				System.out.println("Enter Department Name:");
				String departmentName =sc.next();
				System.out.println("Enter HOD Name: ");
				String hodName =sc.next();
				System.out.println("Enter Departmant Floor: ");
				int departmentFloor = sc.nextInt();

				student[i] =  services.acceptStudentDetails(firstName, lastName, age, gender, city, departmentId, departmentName, hodName, departmentFloor);

				break;

			case 2:
				System.out.println("Enter the First Name of student: ");
				String studentName = sc.next();
				int flag=0;
				if(i==0)
					throw new StudentNotFoundException("Students details not found.");
				for(int j=0;j<=i;j++) {
					if(studentName.equals(stud.getFirstName()))
						flag=1;
				}
				if(flag==1)
					System.out.println(services.getStudentDetails(stud.getStudentId()));
				else
					throw new StudentNotFoundException("Students details not found.");
				break;

			case 3:
				System.out.println("Printing the details of all students....");
				services.getAllStudentsDetails();
				break;

			case 4:System.exit(-1);

			default:
				System.out.println("Invalid Choice.Try Again!!");
				break;	
			}
		}
		
		//DepartmentSystemServices services = new DepartmentSystemImpl();

		
		
		long student1 = services.acceptStudentDetails("Tirtharaj","Sur",22,Gender.Male,"Kolkata",
				11,"CSE","Swagata Paul",1);
		long student2 = services.acceptStudentDetails("Pritam", "Chakraborty", 20, Gender.Other,"Pune",12, "Not Applicable", "Debraj Chatterjee", 2);
		//long student3 = services.acceptStudentDetails("Rochita", "Bagchi", 14, Gender.Female,"Pune",12, "CE", "Debraj Chatterjee", 3);
		System.out.println(student1);
		System.out.println(student2);
		//System.out.println(student3);*/
		
		while(true) {
			System.out.println("\t\t...................................OPERATIONS....................................");
			System.out.println("1.View Details of a student\n2.View Details of all students\n3.Exit");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:	System.out.println("Enter EmployeeId: ");
				long employeeId = sc.nextLong();
				System.out.println(services.getStudentDetails(employeeId));
				break;
			case 2:System.out.println("Printing the details of all students....");
				System.out.println(services.getAllStudentsDetails());
				break;
			case 3:System.exit(-1);
			default:System.out.println("Invalid Choice.Try Again!!");
					break;
			
			}
		}
		
		
		
	}
}
