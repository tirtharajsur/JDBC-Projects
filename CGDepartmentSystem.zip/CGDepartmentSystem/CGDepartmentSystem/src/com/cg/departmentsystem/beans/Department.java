package com.cg.departmentsystem.beans;

public class Department {
	long departmentId;
	String departmentName;
	String hodName;
	int departmentFloor;
	
	public Department() {
		super();
	}
	public Department(long departmentId, String departmentName, String hodName, int departmentFloor) {
		super();
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.hodName = hodName;
		this.departmentFloor = departmentFloor;
	}
	public long getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(long departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getHodName() {
		return hodName;
	}
	public void setHodName(String hodName) {
		this.hodName = hodName;
	}
	public int getDepartmentFloor() {
		return departmentFloor;
	}
	public void setDepartmentFloor(int departmentFloor) {
		this.departmentFloor = departmentFloor;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + departmentFloor;
		result = prime * result + (int) (departmentId ^ (departmentId >>> 32));
		result = prime * result + ((departmentName == null) ? 0 : departmentName.hashCode());
		result = prime * result + ((hodName == null) ? 0 : hodName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (departmentFloor != other.departmentFloor)
			return false;
		if (departmentId != other.departmentId)
			return false;
		if (departmentName == null) {
			if (other.departmentName != null)
				return false;
		} else if (!departmentName.equals(other.departmentName))
			return false;
		if (hodName == null) {
			if (other.hodName != null)
				return false;
		} else if (!hodName.equals(other.hodName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "\nDepartment[departmentId=" + departmentId + "]\nDepartmentName=" + departmentName + "HOD Name="
				+ hodName + " DepartmentFloor=" + departmentFloor;
	}
	
}
