package com.cg.departmentsystem.services;

import java.util.List;
import com.cg.departmentsystem.beans.Department;
import com.cg.departmentsystem.beans.Students;
import com.cg.departmentsystem.enums.Gender;
import com.cg.departmentsystem.exceptions.InvalidAgeException;
import com.cg.departmentsystem.exceptions.StudentNotFoundException;

public interface DepartmentSystemServices {

	long acceptStudentDetails(String firstName, String lastName, int age, Gender gender, String city, long departmentId, String departmentName, String hodName, int departmentFloor)
			throws InvalidAgeException;

	Students getStudentDetails(long studentsId) throws StudentNotFoundException;

	List<Students> getAllStudentsDetails() throws StudentNotFoundException;



}
