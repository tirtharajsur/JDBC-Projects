package com.cg.departmentsystem.services;
import java.util.List;
import com.cg.departmentsystem.beans.Department;
import com.cg.departmentsystem.beans.Students;
import com.cg.departmentsystem.daoservices.StudentsDAO;
import com.cg.departmentsystem.daoservices.StudentsDAOImpl;
import com.cg.departmentsystem.enums.Gender;
import com.cg.departmentsystem.exceptions.InvalidAgeException;
import com.cg.departmentsystem.exceptions.StudentNotFoundException;
public class DepartmentSystemServicesImpl implements DepartmentSystemServices{
	StudentsDAO studentData = new StudentsDAOImpl();
	@Override
	public long acceptStudentDetails(String firstName, String lastName, int age, Gender gender, String city,
			long departmentId, String departmentName, String hodName, int departmentFloor) throws InvalidAgeException {
		if(age<15)
			throw new InvalidAgeException("The Student is under-aged.");
		return studentData.save(new Students(firstName, lastName, age, gender, city, new Department(departmentId, departmentName, hodName, departmentFloor))).getStudentId();
	}
	@Override
	public Students getStudentDetails(long studentsId) throws StudentNotFoundException{
		Students students = studentData.findOne(studentsId);
		if(students==null)
			throw new StudentNotFoundException("Sorry The Student's details are not found!!");
		return students;
	}
	@Override
	public List<Students> getAllStudentsDetails() throws StudentNotFoundException {	
		if(studentData.findAll()==null)
			throw new StudentNotFoundException("No details found.");
		return studentData.findAll();	
	}
}
