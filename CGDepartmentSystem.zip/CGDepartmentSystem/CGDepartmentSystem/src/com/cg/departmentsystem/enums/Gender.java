package com.cg.departmentsystem.enums;

public enum Gender {
		Male,Female,Other
}
