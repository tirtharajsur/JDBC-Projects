package com.cg.banking.client;

import com.cg.banking.util.BankingDBUtil;

public class TestMain {

	public static void main(String[] args) {
		//1st load driver 
				BankingDBUtil.getDBConnection();
				System.out.println("Connection is Open !");
			}

	}

