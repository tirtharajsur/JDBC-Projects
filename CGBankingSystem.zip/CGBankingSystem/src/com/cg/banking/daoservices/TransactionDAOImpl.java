package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;
public class TransactionDAOImpl implements TransactionDAO{

	private static Connection con = BankingDBUtil.getDBConnection();
	
	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		
		try{
			con.setAutoCommit(false);
			PreparedStatement pstmt1 
			= con.prepareStatement("Insert into Transaction(transactionId, amount,transactiontype) values(TRANSACTION_ID_SEQ.NEXTVAL,?,?)");
			
			pstmt1.executeUpdate();
			PreparedStatement pstmt2 = con.prepareStatement("Select max(accountNo) from Account");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int transactionId = rs.getInt(1);
	
		transaction.setTransactionId(transactionId);
		con.commit();
		}catch(SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}catch(SQLException e1){
				e1.printStackTrace();
			}
		}
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Transaction findOne(long accountNo, int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	/*
	 * @Override public Transaction save(long accountNo,Transaction transaction) {
	 * transaction.setTransactionId(BankingDBUtil.getTRANSACTION_ID_COUNTER());
	 * BankingDBUtil.customerDetails.get(accountNo).getTransaction().put((long)
	 * transaction.getTransactionId(),transaction); return transaction; }
	 * 
	 * @Override public boolean update(Transaction transaction) { return false; }
	 * 
	 * @Override public Transaction findOne(long accountNo,int transactionId) {
	 * return BankingDBUtil.customerDetails.get(accountNo).getTransaction().get(
	 * transactionId); }
	 * 
	 * @Override public List<Transaction> findAll(long accountNo) { return new
	 * ArrayList<Transaction>(BankingDBUtil.customerDetails.get(accountNo).
	 * getTransaction().values()); }
	 */
}
