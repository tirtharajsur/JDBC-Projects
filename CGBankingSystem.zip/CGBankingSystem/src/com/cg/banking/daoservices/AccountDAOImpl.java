package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public class AccountDAOImpl implements AccountDAO {
	private static Connection con = BankingDBUtil.getDBConnection();

	@Override
	public Account save(Account account) {
		account.setPinNumber(BankingDBUtil.generatePinNumber());
		account.setAccountStatus("Active");
		try {
			con.setAutoCommit(false);
			
			PreparedStatement pstmt1 
			= con.prepareStatement("Insert into Account(accountNo,pinNumber,accountType,accountStatus,accountBalance) values(ACCOUNT_NO_SEQ.NEXTVAL,?,?,?,?)");
			pstmt1.setLong(1, account.getPinNumber());
			pstmt1.setString(2, account.getAccountType());
			pstmt1.setString(3, account.getAccountStatus());
			pstmt1.setFloat(4, account.getAccountBalance());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("Select max(accountNo) from Account");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int accountNo = rs.getInt(1);
			
			
			account.setAccountNo(accountNo);
			con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				con.rollback();
			}catch(SQLException e1){
				e1.printStackTrace();
			}
		}
		return account;
	}

	@Override
	public boolean update(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		try {
			PreparedStatement pstmt1 = con.prepareStatement("select * from Account where accountNo="+accountNo);
			ResultSet accountRs = pstmt1.executeQuery();
			
			if(accountRs.next()) {
				long pinNumber = accountRs.getLong("pinNumber");
				String accountType = accountRs.getString("accountType");
				String accountStatus = accountRs.getString("accountStatus");
				float accountBalance = accountRs.getFloat("accountBalance");
				
				Account account = new Account(accountNo, pinNumber, accountType, accountStatus, accountBalance, null);
				return account;
				
			}
		
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Account> findAll() {
		ArrayList<Account> accounts = new ArrayList<>();
		try {
			PreparedStatement pstmt1 = con.prepareStatement("select * from Accounts");
			ResultSet accountRs = pstmt1.executeQuery();
			
			while(accountRs.next()) {
				int accountNo = accountRs.getInt("accountId");
				long pinNumber = accountRs.getLong("pinNumber");
				String accountType = accountRs.getString("accountType");
				String accountStatus = accountRs.getString("accountStatus");
				float accountBalance = accountRs.getFloat("accountBalance");
				
				Account account = new Account(accountNo, pinNumber, accountType, accountStatus, accountBalance, null);
				
				
				
				accounts.add(account);
				
			}
		
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accounts;
}
	

	/*
	 * @Override public Account save(Account account) {
	 * account.setAccountNo(BankingDBUtil.getACCOUNT_ID_COUNTER());
	 * account.setPinNumber ((int)(Math.random()*10000));
	 * BankingDBUtil.customerDetails.put(account.getAccountNo(), account); return
	 * account; }
	 * 
	 * @Override public boolean update(Account account) { if
	 * (BankingDBUtil.customerDetails.containsKey(account.getAccountNo())) {
	 * BankingDBUtil.customerDetails.put(account.getAccountNo(), account); return
	 * true; } return false; }
	 * 
	 * @Override public List<Account> findAll() { return new
	 * ArrayList<Account>(BankingDBUtil.customerDetails.values()); }
	 * 
	 * @Override public Account findOne(long accountNo) { return
	 * BankingDBUtil.customerDetails.get(accountNo); }
	 */

}
