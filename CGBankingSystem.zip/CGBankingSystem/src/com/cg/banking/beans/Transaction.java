package com.cg.banking.beans;

public class Transaction {
	@Override
	public String toString() {
		return "Transaction\n [transactionId=" + transactionId + ", amount=" + amount + ", transactiontype="
				+ transactiontype + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(amount);
		result = prime * result + transactionId;
		result = prime * result + ((transactiontype == null) ? 0 : transactiontype.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (Float.floatToIntBits(amount) != Float.floatToIntBits(other.amount))
			return false;
		if (transactionId != other.transactionId)
			return false;
		if (transactiontype == null) {
			if (other.transactiontype != null)
				return false;
		} else if (!transactiontype.equals(other.transactiontype))
			return false;
		return true;
	}
	private int transactionId;
	private float amount;
	private String transactiontype;
	public Transaction() {}
	public Transaction(float amount, String transactiontype) {
		super();
		this.amount = amount;
		this.transactiontype = transactiontype;
	}
	public Transaction(int transactionId, float amount, String transactiontype) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactiontype = transactiontype;
	}
	
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getTransactionId(){
		return transactionId;
		
	}

}
