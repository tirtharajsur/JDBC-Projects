package com.cg.banking.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class BankingDBUtil {
	private static Connection con = null;
	public static Connection getDBConnection() {
		if(con==null) {
			Properties bankingSystemProperties = new Properties();
			try {
				bankingSystemProperties.load(new FileInputStream(new File(".//resources//bankingSystem.properties")));
				String driver = bankingSystemProperties.getProperty("driver");
				String url = bankingSystemProperties.getProperty("url");
				String user = bankingSystemProperties.getProperty("user");
				String password = bankingSystemProperties.getProperty("password");
				Class.forName(driver);
				con=DriverManager.getConnection(url,user,password);
			}catch(IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return con;
	}
	public static int  generatePinNumber() {
		return (int) (Math.random()*10000);	
	}
}
