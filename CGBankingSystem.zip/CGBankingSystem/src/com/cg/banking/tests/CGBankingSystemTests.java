package com.cg.banking.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;

public class CGBankingSystemTests {

	/*
	 * private static BankingServices services; private static Account account;
	 * 
	 * @BeforeClass public static void setUpTestEnv() { services = new
	 * BankingServicesImpl(); account = new Account(); }
	 * 
	 * @Before public void setUpTestdata() { Account account1 = new
	 * Account(10001,1234,"Salary","Active",10000); Account account2 = new
	 * Account(10002,5678,"Savings","Active",9000); Account account3 = new
	 * Account(10003,1478,"Savings","Blocked",8000);
	 * 
	 * 
	 * BankingDBUtil.customerDetails.put(account1.getAccountNo(), account1);
	 * BankingDBUtil.customerDetails.put(account2.getAccountNo(), account2);
	 * BankingDBUtil.customerDetails.put(account3.getAccountNo(), account3);
	 * 
	 * BankingDBUtil.ACCOUNT_ID_COUNTER = 10002; }
	 * ..........................................ACCOUNT RELATED
	 * TESTS................................................
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testGetAccountDetailsForInvalidAccount() throws AccountNotFoundException,
	 * BankingServicesDownException { services.getAccountDetails(12345);
	 * 
	 * }
	 * 
	 * @Test public void testGetAccountDetailsForValidAccount() throws
	 * AccountNotFoundException, BankingServicesDownException { Account
	 * expectedAccount = new Account(10002,5678,"Savings","Active",9000); Account
	 * actualAccount = services.getAccountDetails(10002);
	 * 
	 * Assert.assertEquals(expectedAccount, actualAccount ); }
	 * 
	 * @Test public void testOpenAccountForValidData() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * InvalidAmountException, InvalidAccountTypeException {
	 * Assert.assertEquals(10003,
	 * services.openAccount("Savings",10000).getAccountNo()); }
	 * ................................................DEPOSIT RELATED
	 * TESTS......................................................
	 * 
	 * @Test(expected =AccountNotFoundException.class ) public void
	 * testDepositAmountForInvalidAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException {
	 * services.depositAmount(50002, 2000); }
	 * 
	 * @Test public void testDepositAmountForValidAccount() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException {
	 * 
	 * Account accountsDetails = new Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.depositAmount(accountsDetails.
	 * getAccountNo(), 1000));
	 * 
	 * float expectedBalance = accountsDetails.getAccountBalance(); float
	 * actualBalance = 10000; Assert.assertEquals(expectedBalance, actualBalance,0
	 * ); }
	 * 
	 * @Test public void testDepositAmountForActiveAccount() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException{ Account accountsDetails = new
	 * Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.depositAmount(accountsDetails.
	 * getAccountNo(), 5000)); String expectedStatus =
	 * accountsDetails.getAccountStatus(); String actualStatus = "Active";
	 * Assert.assertEquals( expectedStatus, actualStatus); }
	 * 
	 * @Test(expected =AccountBlockedException.class ) public void
	 * testDepositAmountForBlockedAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException{
	 * services.depositAmount(10003, 5000); }
	 * 
	 * 
	 * 
	 * ................................................WITHDRAWL RELATED
	 * TESTS......................................................
	 * 
	 * 
	 * 
	 * @Test public void testWithdrawAmountForValidAccount() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException, InsufficientAmountException,
	 * InvalidPinNumberException { Account accountsDetails = new
	 * Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.withdrawAmount(accountsDetails.
	 * getAccountNo(),1000,accountsDetails.getPinNumber())); float expectedBalance =
	 * accountsDetails.getAccountBalance(); float actualBalance = 8000;
	 * Assert.assertEquals(expectedBalance, actualBalance,0 ); }
	 * 
	 * @Test(expected =AccountNotFoundException.class ) public void
	 * testWithdrawAmountForInvalidAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException,
	 * InsufficientAmountException, InvalidPinNumberException {
	 * services.withdrawAmount(50002,2000, 1234); }
	 * 
	 * 
	 * @Test public void testWithdrawAmountForValidPinNumber() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException, InsufficientAmountException,
	 * InvalidPinNumberException { Account accountsDetails = new
	 * Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.withdrawAmount(accountsDetails.
	 * getAccountNo(),1000,accountsDetails.getPinNumber())); long expectedPinNumber
	 * =accountsDetails.getPinNumber() ; long actualPinNumber = 5678;
	 * Assert.assertEquals(expectedPinNumber, actualPinNumber ,0 ); }
	 * 
	 * @Test(expected =InvalidPinNumberException.class ) public void
	 * testWithdrawAmountForInalidPinNumber() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException,
	 * InsufficientAmountException, InvalidPinNumberException {
	 * services.withdrawAmount(10002,2000, 1000); }
	 * 
	 * @Test public void testWithdrawAmountForActiveAccount() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException, InsufficientAmountException,
	 * InvalidPinNumberException{ Account accountsDetails = new
	 * Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.withdrawAmount(accountsDetails.
	 * getAccountNo(),1000,accountsDetails.getPinNumber())); String expectedStatus =
	 * accountsDetails.getAccountStatus(); String actualStatus = "Active";
	 * Assert.assertEquals( expectedStatus, actualStatus); }
	 * 
	 * @Test(expected =AccountBlockedException.class ) public void
	 * testWithdrawAmountForBlockedAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException,
	 * InsufficientAmountException, InvalidPinNumberException {
	 * services.withdrawAmount(10003,2000, 1478); }
	 * 
	 * 
	 * @Test public void testWithdrawAmountForSufficientBalance() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException, InsufficientAmountException,
	 * InvalidPinNumberException { Account accountsDetails = new
	 * Account(10002,5678,"Salary","Active",9000);
	 * accountsDetails.setAccountBalance(services.withdrawAmount(accountsDetails.
	 * getAccountNo(),1000,accountsDetails.getPinNumber())); float expectedBalance =
	 * accountsDetails.getAccountBalance(); float actualBalance = 8000;
	 * Assert.assertEquals( expectedBalance, actualBalance,0); }
	 * 
	 * @Test(expected =InsufficientAmountException.class ) public void
	 * testWithdrawAmountForInsufficientBalance() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException,
	 * InsufficientAmountException, InvalidPinNumberException { Account
	 * accountsDetails = new Account(10002,5678,"Salary","Blocked",9000);
	 * System.out.println(accountsDetails); services.withdrawAmount(10002,12000,
	 * 5678); }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * @After public void tearDownTestData() {
	 * BankingDBUtil.customerDetails.clear();
	 * BankingDBUtil.ACCOUNT_ID_COUNTER=10000; }
	 * 
	 * 
	 * @AfterClass public static void tearDownTestEnv() { services = null; account =
	 * null; }
	 */
}
